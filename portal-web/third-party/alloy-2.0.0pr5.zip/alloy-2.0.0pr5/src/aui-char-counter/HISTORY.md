aui-char-counter
========
